
import java.rmi.*;
import java.rmi.server.*;
import java.io.*;

public class AdminClient
{
	public static String[][] login={
					{"DVLA1111","DVLA1111"},{"DVLA1112","DVLA1112"},{"DVLA1113","DVLA1113"},
					{"KKLA1111","KKLA1111"},{"KKLA1112","KKLA1112"},{"KKLA1113","KKLA1113"},
					{"WSTA1111","WSTA1111"},{"WSTA1112","WSTA1112"},{"WSTA1113","WSTA1113"}};
	
	public static void main(String args[])throws IOException
	{
		String roomno;
		String room_slot="";
		int roomslotchoice;
		String username,password;
		String camp;
		String name="";
		System.out.println("\n\n\n\t\t\t-------------Login--------------");
		DataInputStream ip=new DataInputStream(System.in);
		System.out.print("\n\n\t\t Username : ");
		username=ip.readLine();
		System.out.print("\n\n\t\t Password : ");
		password=ip.readLine();
	
		for(int i=0;i<9;i++)
		{
			if(login[i][0].equals(username))
			{
				if(login[i][1].equals(password))
				{
					camp=login[i][0].substring(0,3);
					System.out.print("\n\n\t\tSuccessful login..! Connecting to server...\n\n\n");
					switch (camp) 
					{
							case "WST":name = "rmi://localhost:9999/WstBookingSystem";break;
							case "DVL":name = "rmi://localhost:9999/DvlBookingSystem";break;
							case "KKL":name = "rmi://localhost:9999/KklBookingSystem";break;
					}
					System.out.print(login[i][1]);
					System.out.print("\t");
				}
				else
					System.exit(0);
			}
		}
		try
		{
			RoomBookingInterface rbi;
			System.setSecurityManager ( new RMISecurityManager ( ));  
			
			rbi =(RoomBookingInterface) Naming.lookup (name);
			
			while(true)
			{
			System.out.println("\n\n\n\tConnected to Server...!");
			System.out.println(" ");
			System.out.println("\t\t\t--------------Room Admin Service----------------");
			System.out.println("");
			System.out.println("\n\n\t\tPlease select an option ");
			System.out.println("");
			System.out.println("\t1. Create Rooms");
			System.out.println("\t2. Delete Rooms");
			System.out.println("\t3. Exit ");
			System.out.println("");
			BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("\n\n\t choose any option (1-3) :");
			System.out.print("");
			System.out.flush();
			String response = input.readLine();
			int i = Integer.parseInt(response);
			
			switch (i)
			{
			
				case 1: 
				
					System.out.println("\n\n\tCreating room...");
					System.out.print("\n\n\tEnter the room no (RRXXXX): ");
					roomno=input.readLine();
					System.out.print("\n\tEnter the date (DD-MM-YYYY): ");
					String date=input.readLine();
					System.out.print("\n\tChoose a slot time :");
					System.out.println ("\n\n\t 1. 8-10 \n\t 2. 10-12 \n\t 3. 12-14 \n\t 4. 14-16 \n\t 5. 16-18 \n\t 6. 18-20"); 
					roomslotchoice=Integer.parseInt(input.readLine());
					switch(roomslotchoice)
					{
						case 1: room_slot="8-10";break;
						case 2: room_slot="10-12";break;
						case 3: room_slot="12-14";break;
						case 4: room_slot="14-16";break;
						case 5: room_slot="16-18";break;
						case 6: room_slot="18-20";break;
					}
					
					
					String createlog=rbi.createRoom(roomno,date,room_slot,username);
					String defaultLogFile="E:\\Admin_Client_"+username+"_log.txt";
			
					try (FileWriter f = new FileWriter(defaultLogFile, true); BufferedWriter b = new BufferedWriter(f); PrintWriter p = new PrintWriter(b);)
					{ 
						p.println(createlog);  
					} 
					catch (IOException ioe) { ioe.printStackTrace(); }
					
					System.out.println("Status :  ");   
					System.out.println(createlog);	
					break;					
				case 2:	
					System.out.println("\n\n\t\t Deleting room");
					System.out.print("\n\n\t Enter the room no (RRXXXX) : ");
					roomno=input.readLine();
					System.out.print("\n\n\t Enter the date (DD-MM-YYYY) : ");
					date=input.readLine();							
					System.out.print("\n\n\t Enter the slot time (8AM-10PM) :");
					room_slot=input.readLine();
					String deletelog=rbi.deleteRoom(roomno,date,room_slot,username);
					defaultLogFile="E:\\Admin_Client_"+username+"_log.txt";
					
					try (FileWriter f = new FileWriter(defaultLogFile, true); BufferedWriter b = new BufferedWriter(f); PrintWriter p = new PrintWriter(b);)
					{ 
						p.println(deletelog);  
					} 
					catch (IOException ioe) 
					{
						System.out.println("Error in Connection : ");
						ioe.printStackTrace(); 
					}
					System.out.println(deletelog);	
					break;
				case 3: 
					System.out.println("Closing");   //User has quit the application.
					System.exit(0);
					break;
			}
		}
	}
	catch(Exception e)
	{
		System.out.println("Error in Connection : ");
		e.printStackTrace();
	}	
	}
}

	