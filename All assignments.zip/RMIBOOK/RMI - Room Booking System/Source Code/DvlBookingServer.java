import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.net.*;
class DvlRoomRecord
{
	String roomno,date,timeslot,bookedby,bookingid;
	public DvlRoomRecord(String roomno,String date,String timeslot,String bookedby,String bookingid)
	{
		this.roomno=roomno;
		this.date=date;
		this.timeslot=timeslot;
		this.bookedby=bookedby;
		this.bookingid=bookingid;
	}
}
public class DvlBookingServer extends UnicastRemoteObject implements RoomBookingInterface
{
  protected static String defaultLogFile ="";
  public DvlRoomRecord rr;
  HashMap<Integer,DvlRoomRecord> roomrec=new HashMap<Integer,DvlRoomRecord>();  
  public DvlBookingServer ( ) throws RemoteException {  super ( ); }
  
	public String createRoom(String no,String date,String timeslot,String username)
	{
		String check="false";
		defaultLogFile="E:\\DVLCampus_Server_Logs_"+username+"_log.txt";
		int count= (int) (new Date().getTime()/1000);
		String log="",flag="",bookedby="-",bookingid="-";
		try
		{
			if(!roomrec.isEmpty())
			{	
				Iterator it1 = roomrec.entrySet().iterator();
				while (it1.hasNext()) 
				{
					Map.Entry pair = (Map.Entry)it1.next();
					DvlRoomRecord ras=(DvlRoomRecord)pair.getValue();
					System.out.println(ras.date.equals(date)+","+ras.timeslot.equals(timeslot)+","+ras.roomno.equals(no));
					
					if(ras.date.equals(date)==true && ras.timeslot.equals(timeslot)==true && ras.roomno.equals(no)==true)
					{
						if(check=="true")
						{	
							check="false";
							log="Room Creation \t Unsuccessful \t Room No : "+no+"\t Date : "+date+" TimeSlot : "+timeslot+"\t Booked by : "+bookedby+ "\t Booking ID :" +bookingid ;  
							break;
						}
						else
							break;
					}
					else
						check="true";
				}
			}
			else
			{
				rr=new DvlRoomRecord(no,date,timeslot,bookedby,bookingid);
				synchronized (this){
				roomrec.put(count,rr); 
				}
				log="Room Creation \t Successful \t Room No : "+no+"\t Date : "+date+" TimeSlot : "+timeslot+"\t Booked by : "+bookedby+ "\t" +bookingid ;  	log="Room Creation \t Successful \t Room No : "+no+"\t Date : "+date+" TimeSlot : "+timeslot+"\t Booked by : "+bookedby+ "\t Booking ID :" +bookingid ;  
			}
			if(check=="true")
			{
				rr=new DvlRoomRecord(no,date,timeslot,bookedby,bookingid);
				synchronized(this){
				roomrec.put(count,rr);
				}
				log="Room Creation \t Successful \t Room No : "+no+"\t Date : "+date+" TimeSlot : "+timeslot+"\t Booked by : "+bookedby+ "\t" +bookingid ;  	log="Room Creation \t Successful \t Room No : "+no+"\t Date : "+date+" TimeSlot : "+timeslot+"\t Booked by : "+bookedby+ "\t Booking ID :" +bookingid ;  
			}
		}catch(Exception eere){}	
		try (FileWriter f = new FileWriter(defaultLogFile, true); BufferedWriter b = new BufferedWriter(f); PrintWriter p = new PrintWriter(b);)
		{ 
			p.println(log); 
		} 
		catch (IOException i) { i.printStackTrace(); }
		System.out.println("\n\n\t\t Available rooms-slots in DVL campus ");
		System.out.print("\t\t------------------------------------\n\n");
		Iterator itview = roomrec.entrySet().iterator();
		while (itview.hasNext()) 
		{
			Map.Entry pair = (Map.Entry)itview.next();
			DvlRoomRecord ras=(DvlRoomRecord)pair.getValue();
			System.out.println("Room No : "+ras.roomno+" Date : "+ras.date+" TimeSlot : "+ras.timeslot+" Booked by : "+ras.bookedby+ " Booking ID :" +ras.bookingid+""); 
		}
		return log;
}


	public String Get(String m)
	{
		String modifiedSentence1="";
		try{
		DatagramSocket clientSocket1 = new DatagramSocket();
		InetAddress IPAddress1 = InetAddress.getByName("localhost");
		byte[] sendData1 = new byte[1024];
		byte[] receiveData1 = new byte[1024];
		String sentence1 = m;
		sendData1 = sentence1.getBytes();
		DatagramPacket sendPacket1 = new DatagramPacket(sendData1, sendData1.length, IPAddress1, 9999);
		clientSocket1.send(sendPacket1);
		DatagramPacket receivePacket1 = new DatagramPacket(receiveData1, receiveData1.length);
		clientSocket1.receive(receivePacket1);
		modifiedSentence1 = new String(receivePacket1.getData());
		System.out.println("FROM SERVER:" + modifiedSentence1);
		clientSocket1.close();
		}catch(Exception e){}		
		return modifiedSentence1;


	}

	public String getAvailableTimeSlot(String date,String username)
 {
	 
	int count=0;
	defaultLogFile="E:\\DVLCampus_Server_Logs_"+username+"_log.txt";
	String log="",flag="",bookedby="-",bookingid="-";
	try
	{
		if(!roomrec.isEmpty())
		{	
		Iterator it1 = roomrec.entrySet().iterator();
			while (it1.hasNext()) 
			{
				Map.Entry pair = (Map.Entry)it1.next();
				KklRoomRecord ras=(KklRoomRecord)pair.getValue();
				if(ras.date.equals(date)==true && ras.bookedby=="-")
				{
						count++;
						
				}
			}
			
			log="Checking Availability\tNo of rooms : "+count;
			System.out.println("\n\n\tNo of available rooms : "+count);
			
		}
		else
		{
			log="Checking Availability\t No rooms available : Campus doesn't have any rooms";
		}
	}catch(Exception eere){}	
	
	try (FileWriter f = new FileWriter(defaultLogFile, true); BufferedWriter b = new BufferedWriter(f); PrintWriter p = new PrintWriter(b);)
	{ 
		p.println(log); 
	} 
	catch (IOException i) { i.printStackTrace(); }
	System.out.println("\n\n\t\t Available rooms-slots in DVL campus ");
	System.out.print("\t\t------------------------------------\n\n");
	Iterator itview = roomrec.entrySet().iterator();
	while (itview.hasNext()) 
	{
		Map.Entry pair = (Map.Entry)itview.next();
		KklRoomRecord ras=(KklRoomRecord)pair.getValue();
		System.out.println("Room No : "+ras.roomno+" Date : "+ras.date+" TimeSlot : "+ras.timeslot+" Booked by : "+ras.bookedby+ " Booking ID :" +ras.bookingid+""); 
	}
	return log;
} 

		
public String deleteRoom(String no,String date,String timeslot,String username)
{
	
	String check="false";
	defaultLogFile="E:\\DVLCampus_Server_Logs_"+username+"_log.txt";
	int count= (int) (new Date().getTime()/1000);
	String log="",flag="",bookedby="-",bookingid="-";
	try
	{
		if(!roomrec.isEmpty())
		{	log="";
			Iterator it1 = roomrec.entrySet().iterator();
			while (it1.hasNext()) 
			{
				Map.Entry pair = (Map.Entry)it1.next();
				DvlRoomRecord ras=(DvlRoomRecord)pair.getValue();
				
				if(ras.date.equals(date)==true && ras.timeslot.equals(timeslot)==true && ras.roomno.equals(no)==true)
				{
					
					synchronized(this){roomrec.remove(pair.getKey(),(DvlRoomRecord)pair.getValue());}
					log="Room Deletion \t Successful \t Room No : "+no+"\t Date : "+date+" TimeSlot : "+timeslot+"\t Booked by : "+bookedby+ "\t Booking ID : " +bookingid ; 
					if(check=="true")
					{	
						check="false";
						break;
					}
					else
						break;
				}
				else
					check="true";
			}
		}
		else
			log="Room Deletion \t Unsuccessful \t Room No : "+no+"\t Date : "+date+" TimeSlot : "+timeslot+"\t Booked by : "+bookedby+ "\t Booking ID : " +bookingid ; 
			
		if(check=="false")
		{
		}
	}catch(Exception eere){}	
	try (FileWriter f = new FileWriter(defaultLogFile, true); BufferedWriter b = new BufferedWriter(f); PrintWriter p = new PrintWriter(b);)
	{ 
		p.println(log); 
	} 
	catch (IOException i) { i.printStackTrace(); }
	System.out.println("\n\n\t\t Available rooms-slots in DVL campus ");
	System.out.print("\t\t------------------------------------\n\n");
	Iterator itview = roomrec.entrySet().iterator();
	while (itview.hasNext()) 
	{
		Map.Entry pair = (Map.Entry)itview.next();
		DvlRoomRecord ras=(DvlRoomRecord)pair.getValue();
		System.out.println("Room No : "+ras.roomno+" Date : "+ras.date+" TimeSlot : "+ras.timeslot+" Booked by : "+ras.bookedby+ " Booking ID :" +ras.bookingid+""); 
	}
	return log;
}


public String cancelBooking (String booking_id,String username,String no,String date,String timeslot)throws RemoteException
{
	String check="false";
	defaultLogFile="E:\\DVLCampus_Server_Logs_"+username+"_log.txt";
	int count= (int) (new Date().getTime()/1000);
	String log="",flag="",bookedby="-",bookingid="-";
	try
	{
			if(!roomrec.isEmpty())
			{	log="";
				Iterator it1 = roomrec.entrySet().iterator();
				while (it1.hasNext()) 
				{
					Map.Entry pair = (Map.Entry)it1.next();
					DvlRoomRecord ras=(DvlRoomRecord)pair.getValue();
					
					if(ras.date.equals(date)==true && ras.timeslot.equals(timeslot)==true && ras.roomno.equals(no)==true && ras.bookedby!="-" && (ras.bookedby.equals(username)))
					{
						int k=(int)pair.getKey();
						DvlRoomRecord rc=(DvlRoomRecord)pair.getValue();
						synchronized(this){
						roomrec.remove(pair.getKey(),(DvlRoomRecord)pair.getValue());
						rc.bookedby="-";
						rc.bookingid="-";
						
						System.out.println("\n\n Room is cancelled by : "+username);
						roomrec.put(k,(DvlRoomRecord)rc);
						}
						log="Room Cancellation\t Successful \t Date : "+ras.date+"\tTime slot : "+ras.timeslot+"\t Room no : "+ras.roomno+"\t Cancelled by : "+ras.bookedby+ "\t Booking ID : "+ras.bookingid;
					}
					else
					{
						log="Room Cancellation\t Unsuccessful \t Date : "+date+"\tTime slot : "+timeslot+"\t Room no : "+no+"\t Booking ID : "+booking_id;
					}						
				}
			}
		else
			log="";
		
	}catch(Exception ex){}
	if(log=="")
		log=" Unable to cancel room! Record doesnt exists : \tRoom no : "+no+"\t Date :"+date+"\t Time slot : "+timeslot;
			
	try (FileWriter f = new FileWriter(defaultLogFile, true); BufferedWriter b = new BufferedWriter(f); PrintWriter p = new PrintWriter(b);)
	{ 
		p.println(log); 
	} 
	catch (IOException i) { i.printStackTrace(); }
	
	System.out.println("\n\n\t\t Available rooms-slots in DVL campus ");
	System.out.print("\t\t------------------------------------\n\n");
	
	
	Iterator it = roomrec.entrySet().iterator();
	while (it.hasNext()) 
	{
		Map.Entry pair = (Map.Entry)it.next();
		DvlRoomRecord ras=(DvlRoomRecord)pair.getValue();
		System.out.println(pair.getKey() + " = " + ras.roomno+","+ras.date+" ,"+ras.timeslot+"  Booked by : "+ras.bookedby+" Booking ID : "+ras.bookingid);
	}
	return log;
  }
  

  public String bookRoom(String no,String date,String timeslot,String username)throws RemoteException	
  {
	  
	
	String check="false";
	defaultLogFile="E:\\DVLCampus_Server_Logs_"+username+"_log.txt";
	int count= (int) (new Date().getTime()/1000);
	String log="",flag="",bookedby="-",bookingid="-";
	int max=0;
	int booklim=0;
	try
	{
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		
		if(!roomrec.isEmpty())
		{
			Iterator rese = roomrec.entrySet().iterator();
			while (rese.hasNext()) 
			{
				Map.Entry lim= (Map.Entry)rese.next();
				DvlRoomRecord res=(DvlRoomRecord)lim.getValue();
			
				Date date1 = df.parse(date);
				Date date2 = df.parse(res.date);
				Calendar cal = Calendar.getInstance();
				
				
				cal.setTime(date1);
				int weekcur = cal.get(Calendar.WEEK_OF_YEAR);
				cal.setTime(date2);
				int weekpre = cal.get(Calendar.WEEK_OF_YEAR);
				
				if(weekcur==weekpre && res.bookedby!="-" )
				{
					booklim++;
				}		
			}
		}

		if(!roomrec.isEmpty())
		{	log="";
	
			Iterator it1 = roomrec.entrySet().iterator();
			while (it1.hasNext()) 
			{
				Map.Entry pair = (Map.Entry)it1.next();
				DvlRoomRecord ras=(DvlRoomRecord)pair.getValue();
				System.out.println(ras.date.equals(date)+","+ras.timeslot.equals(timeslot)+","+ras.roomno.equals(no));
				
				if(ras.date.equals(date)==true && ras.timeslot.equals(timeslot)==true && ras.roomno.equals(no)==true && ras.bookedby=="-" && booklim<3)
				{
	   				int k=(int)pair.getKey();
					DvlRoomRecord rc=(DvlRoomRecord)pair.getValue();
					synchronized(this){
					roomrec.remove(pair.getKey(),(DvlRoomRecord)pair.getValue());
					rc.bookedby=username;
					rc.bookingid=username+""+(int)(new Date().getTime()/1000);
					bookingid=rc.bookingid;
					System.out.println("\n\n Room is booked by : "+rc.bookedby);
					roomrec.put(k,(DvlRoomRecord)rc);
					}
					log="Roombooking Successful\t"+" Room No : "+ ras.roomno+"\t Booking Date : "+ras.date+"\t Timeslot : "+ras.timeslot+"\t Booked by : "+username+"\t Booking ID : "+bookingid;
;
				}
				else
				{
					log="Roombooking unsuccessful\t"+" Room No : "+ no+"\t Booking Date : "+date+"\t Timeslot : "+timeslot;
					
				}						
			}
		}
		else
			log="";
				
	}catch(Exception ex){}
	if(log=="")
		log=" Unable to book room! Record doesnt exists : Room no : "+no+"; Date :"+date+"; Time slot : "+timeslot+"; Booked by : - \t Booking ID : -";
			
	try (FileWriter f = new FileWriter(defaultLogFile, true); BufferedWriter b = new BufferedWriter(f); PrintWriter p = new PrintWriter(b);)
	{ 
		p.println(log); 
	} 
	catch (IOException i) { i.printStackTrace(); }
	System.out.println("\n\n\t\t Available rooms-slots in DVL campus ");
	System.out.print("\t\t------------------------------------\n\n");
	
	
	Iterator it = roomrec.entrySet().iterator();
	while (it.hasNext()) 
	{
		Map.Entry pair = (Map.Entry)it.next();
		DvlRoomRecord ras=(DvlRoomRecord)pair.getValue();
		System.out.println(pair.getKey() + " = " + ras.roomno+","+ras.date+" ,"+ras.timeslot+"  Booked by : "+ras.bookedby+" Booking ID : "+ras.bookingid);
	}
	return log;
  }
  
  public static void main (String[] args)
  {
     Thread t1=new Thread( new Runnable(){ 
	public void run(){
	try
	{
		DvlBookingServer server = new DvlBookingServer ();
		String name = "rmi://localhost:9999/DvlBookingSystem";
		Naming.rebind (name, server);
		System.out.println (name + " is running");
	}
	catch (Exception ex)
	{
		System.err.println (ex);
	}
	}});
	
	t1.start();
		
			/*
	Thread t2=new Thread( new Runnable(){ 
	public void run(){
	try
	{
		
		
			DatagramSocket clientSocket2 = new DatagramSocket();
			InetAddress IPAddress2 = InetAddress.getByName("localhost");
			byte[] sendData2 = new byte[1024];
			byte[] receiveData2 = new byte[1024];
			
		while(true)
		{
			DatagramPacket receivePacket2 = new DatagramPacket(receiveData2, receiveData2.length);
			clientSocket2.receive(receivePacket2);
			String modifiedSentence2 = new String(receivePacket2.getData());
			if(modifiedSentence2.equals("WST"))
			{
			
					String sentence2 = "50";
					sendData2 = sentence2.getBytes();
					DatagramPacket sendPacket1 = new DatagramPacket(sendData1, sendData1.length, IPAddress1, 9999);
					clientSocket2.send(sendPacket2);
			}
			System.out.println("FROM SERVER: main" + modifiedSentence2);

		}
		
		
	}
	catch (Exception ex)
	{
		System.err.println (ex);
	}
	}});
	
	t2.start();
		
	*/
	
	
	
	
  }
}

 	