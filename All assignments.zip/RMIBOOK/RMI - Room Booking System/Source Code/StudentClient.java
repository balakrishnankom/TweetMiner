
import java.rmi.*;
import java.rmi.server.*;
import java.io.*;

public class StudentClient
{
	public static String[][] login={
					{"DVLS1111","DVLS1111"},{"DVLS1112","DVLS1112"},{"DVLS1113","DVLS1113"},
					{"KKLS1111","KKLS1111"},{"KKLS1112","KKLS1112"},{"KKLS1113","KKLS1113"},
					{"WSTS1111","WSTS1111"},{"WSTS1112","WSTS1112"},{"WSTS1113","WSTS1113"}};
	
	public static void main(String args[])throws IOException
	{
		String username,password;
		int roomslotchoice;
		String room_slot="";
		String camp="";
		String name="";
		RoomBookingInterface rbi;
		DataInputStream ip=new DataInputStream(System.in);
		System.out.println("\n\n\n\t\t\t-------------Login--------------");
		System.out.print("\n\n\t\t Username : ");
		username=ip.readLine();
		System.out.print("\n\n\t\t Password : ");
		password=ip.readLine();

		for(int i=0;i<9;i++)
		{
			if(login[i][0].equals(username))
			{
				if(login[i][1].equals(password))
				{
					camp=login[i][0].substring(0,3);
					
					System.out.print("\n\n\t\tSuccessful login..! Connecting to server...");
					switch (camp) 
					{
						case "WST":name = "rmi://localhost:9999/WstBookingSystem";break;
						case "DVL":name = "rmi://localhost:9999/DvlBookingSystem";break;
						case "KKL":name = "rmi://localhost:9999/KklBookingSystem";break;
					}
				}
			}
		}
	
		while(true)
		{
			try
			{
				System.setSecurityManager ( new RMISecurityManager ( ));  //set up the security manager
				rbi =(RoomBookingInterface) Naming.lookup (name);
				//System.out.println("\n\n\t\tConnected to Server...!");
				System.out.println("\n\n\t\t--------------------Room Booking Service--------------------");
				System.out.println("\n\n\tPlease select a service");
				System.out.println("\t1. Book Rooms");
				System.out.println("\t2. Get availability of room");
				System.out.println("\t3. Cancel booking");
				System.out.println("\t4. Exit ");
				BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
				System.out.print("\tChoose any option (0-4) :");
				System.out.flush();
				String response = input.readLine();
				int i = Integer.parseInt(response);
				try
				{
					switch (i)
					{
						case 1:
							System.out.println("\n\t\tRoom Booking Service - Rooms can be booked from 8am to 8pm");
							System.out.print("\n\t\tEnter the room name : ");
							String roomno= input.readLine();
							System.out.print("\n\t\tEnter the date : "); 
							String date = input.readLine();
							System.out.print("\n\tChoose a slot time :");
							System.out.println ("\n\n\t 1. 8-10 \n\t 2. 10-12 \n\t 3. 12-14 \n\t 4. 14-16 \n\t 5. 16-18 \n\t 6. 18-20"); 
							roomslotchoice=Integer.parseInt(input.readLine());
							switch(roomslotchoice)
							{
								case 1: room_slot="8-10";break;
								case 2: room_slot="10-12";break;
								case 3: room_slot="12-14";break;
								case 4: room_slot="14-16";break;
								case 5: room_slot="16-18";break;
								case 6: room_slot="18-20";break;
							}
							String resp = rbi.bookRoom(roomno,date,room_slot,username);
							System.out.println("Log :"+resp);
							break;
						case 2:
							System.out.println("\n\t\t Available rooms ");
							System.out.print("\n\t\t Enter the date : ");
							date= input.readLine();
							String repo=rbi.getAvailableTimeSlot(date,username);
							System.out.print("Available Rooms : "+repo);
							break;
						case 3:	
							System.out.println("\n\t\tRoom Cancelling Service ");
							System.out.println("\n\t\tTime slots go from 0 for 8am up to 11 for 7pm - Enter a value in this range");
							System.out.print("\n\t\tEnter the room name : ");
							roomno= input.readLine();
							System.out.print("\n\t\tEnter the date : "); 
							date = input.readLine();
							System.out.print("\n\tChoose a slot time :");
							System.out.println ("\n\n\t 1. 8-10 \n\t 2. 10-12 \n\t 3. 12-14 \n\t 4. 14-16 \n\t 5. 16-18 \n\t 6. 18-20"); 
							roomslotchoice=Integer.parseInt(input.readLine());
							System.out.print("\n\n\t Enter the booking ID : ");
							String booking_id=input.readLine();
							switch(roomslotchoice)
							{
								case 1: room_slot="8-10";break;
								case 2: room_slot="10-12";break;
								case 3: room_slot="12-14";break;
								case 4: room_slot="14-16";break;
								case 5: room_slot="16-18";break;
								case 6: room_slot="18-20";break;
							}
							String respcan = rbi.cancelBooking(booking_id,username,roomno,date,room_slot);
							System.out.println("Cancel status  :"+respcan);	  
							break;
						case 4:
							System.out.println("\tClosing..."); 
							System.exit(0);
							break;
					
					}	
				}catch(Exception e){}
				
			}catch(Exception e){ e.printStackTrace();}	
		}
	}
}

	