#TweetAnalaytics

##Group Member Information 

1. Jaskarandeep Singh Chhabra 40045485
2. Jasmeet Singh Chhabra 40055181
3. Manjyot Singh Saini 40059882
4. Navroop Virk 40043821
5. Sunpreet Singh 40015564


##List of Tasks

1. Reading Twitter API and play framework Documentation .
2. Setting up version control
3. Creating twitter Developer App and generating access token 
4. Creating view to input the keyword from user.
5. Defining the Routes.
6. Fetching tweets related to the keyword using twitter search tweet API.
7. Displaying the retrieved data on a view .
8. Fetching user details from twitter User Api using screen name.
9. Displaying user data on a view .
10. Linking displayed tweets with user profile.
11. UI improvements
12. Code Refactoring 
13. Java docs
14. Creating Unit Test 
15. Testing and check the Test coverage using JaCoCo.


##List of Methods - 

1. Welcome
2. tweetSearch
3. searchSubmit
4. userSearch
5. userSubmit

##List of Test methods

1. userSearch
2. welcome
3. tweetSearch


##Contribution 

1. Jaskarandeep Singh Chhabra 40045485

* Task 1 - Reading Twitter API and play framework Documentation .
* Task 4 - Creating view to input the keyword from user.
* Task 9 - Displaying user profile data on a view .
* Task 15 - Testing and check the Test coverage using JaCoCo.
* Task 11 - UI improvements

Implemented Method - welcome


2. Jasmeet Singh Chhabra 40055181

* Task 1 - Reading Twitter API and play framework Documentation .
* Task 7 - Displaying the retrieved tweets data on a view .
* Task 10 - Linking displayed tweets with user profile route.
* Task 14 - Creating Unit Test 

Implemented Test Method - tweetSearch


3. Manjyot Singh Saini 40059882

* Task 1 - Reading Twitter API and play framework Documentation .
* Task 3 - Creating twitter Developer App and generating access token 
* Task 6 - Fetching tweets related to the keyword using twitter search tweet API.
* Task 11 - UI improvements
* Task 12 - Code Refactoring 

Implemented Method - tweetSearch 
Implemented Method - searchSubmit


4. Navroop Virk 40043821

* Task 1 - Reading Twitter API and play framework Documentation .
* Task 2 - Setting up version control
* Task 8 - Fetching user details from twitter User Api using screen name.
* Task 13 - Java docs 

Implemented Method - userSearch 
Implemented Method - userSubmit


5. Sunpreet Singh 40015564

* Task 1 - Reading Twitter API and play framework Documentation .
* Task 5 - Defining the Routes.
* Task 12 - Code Refactoring 
* Task 14 - Creating Unit Test 

Implemented Test Method - userSearch
Implemented Test Method  -welcome


##Technical notes:

* sbt run: To run the project, which will automatically resolve all dependencies.
* sbt jacoco: Generates test coverage from test cases.
* sbt test: To run all the test cases; Http status 200: OK
* sbt clean: cleaning up build files from the project directory.
