package actors;

public class Messages {

    public static class RequestForNewTweets {

        public String newKeyWord;

        public RequestForNewTweets(String newKeyWord) {
            this.newKeyWord = newKeyWord;
        }

    }

    public static class RegisterClients {
        //
    }

}
