package actors;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;
import com.fasterxml.jackson.databind.node.ObjectNode;
import play.libs.Json;
import play.mvc.Result;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;
import java.util.*;

public class TweetActor extends AbstractActor {

    List<String> listOfTweetKeywords=new ArrayList<String>() ;
    private  ActorRef wsOutActor;
    TwitterStream twitterStream=null;
    public static Props props(final ActorRef wsout) {
        return Props.create(TweetActor.class, wsout);
    }

    public TweetActor( ActorRef wsOutActor) {

        this.wsOutActor=wsOutActor;
        context().actorSelection("/user/userParentActor/").tell(new Messages.RegisterClients(),self());
        //TwitterStreamsTest();
    }

    @Override
    public void preStart() {
        System.out.println("TweetActor actor started");
    }

    @Override
    public void postStop() {
        System.out.println("TweetActor actor stopped");
        if(twitterStream!=null){
            twitterStream.cleanUp();
        }
        // twitterStream.shutdown();
    }

    @Override
    public Receive createReceive() {
        return  receiveBuilder()
                .match(Messages.RequestForNewTweets.class,msg->{
                    listOfTweetKeywords.add(msg.newKeyWord);
                    if(twitterStream!=null){
                        twitterStream.cleanUp();
                    }
                    TwitterStreamsTest();
                }).build();
    }

    public void TwitterStreamsTest() {
        ConfigurationBuilder configBuilder= new ConfigurationBuilder();
        configBuilder.setDebugEnabled(true)
                .setOAuthConsumerKey("0AZpxC7v99PWQ9Pyq4XOUtDUG")
                .setOAuthConsumerSecret("Xz4qRzpaIE0cElgpnkFtf9vR2O0tL7BtEqKWd18SYiYcPsHQkJ")
                .setOAuthAccessToken("58406433-T4TaAocRdqoWYB8fsZTLyKUp1pQ4MbevgkFyc73By")
                .setOAuthAccessTokenSecret("D7qz32jKTDFiOazLDjREOtHRWXxDmWl11qNYcOFv6cSAl");
        Configuration config=configBuilder.build();
        twitterStream= new TwitterStreamFactory(config).getInstance();
        StatusListener listener = new StatusListener() {

            @Override
            public void onException(Exception e) {
                e.printStackTrace();
            }
            @Override
            public void onDeletionNotice(StatusDeletionNotice arg) {
            }
            @Override
            public void onScrubGeo(long userId, long upToStatusId) {
            }
            @Override
            public void onStallWarning(StallWarning warning) {
                System.out.println(warning);
            }
            @Override
            public void onStatus(Status status) {
                String text=status.getText();
                String userName=status.getUser().getName();
                String screenName=status.getUser().getScreenName();
                ObjectNode twitterObject= Json.newObject();
                twitterObject.put("Tweet",text);
                twitterObject.put("Name",userName);
                twitterObject.put("ScreenName",screenName);
                wsOutActor.tell(twitterObject,self());
            }
            @Override
            public void onTrackLimitationNotice(int numberOfLimitedStatuses) {
                System.out.println("what is ths "+numberOfLimitedStatuses);
            }
        };

        twitterStream.addListener(listener);
        FilterQuery tweetFilterQuery = new FilterQuery();
        tweetFilterQuery.track(listOfTweetKeywords.toArray(new String[0]));
        tweetFilterQuery.language(new String[]{"en"});
        twitterStream.filter(tweetFilterQuery);
    }
}

