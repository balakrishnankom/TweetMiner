package actors;

import akka.actor.*;
import akka.stream.Materializer;
import akka.util.Timeout;
import com.fasterxml.jackson.databind.node.ObjectNode;
import play.libs.Json;
import scala.concurrent.duration.Duration;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.TimeUnit;

import static akka.pattern.PatternsCS.ask;
import static akka.pattern.PatternsCS.pipe;

public class UserParentActor extends AbstractActor {

    private final Materializer materializer;
    private final ActorSystem system;
    private final Timeout timeout = new Timeout(Duration.create(5, TimeUnit.SECONDS));
    ArrayList<ActorRef> tweetActors =new ArrayList<>();

    public UserParentActor(ActorSystem system, Materializer materializer) {
        this.materializer = materializer;
        this.system = system;
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(Messages.RegisterClients.class,msg->{tweetActors.add(sender());})
                .match(Messages.RequestForNewTweets.class,msg->{tweetActors.forEach(tweetTrialActor -> tweetTrialActor.tell(msg,self()));})
                .build();
    }

}


