package controllers;

import actors.Messages;
import actors.TweetActor;
import actors.UserParentActor;
import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.stream.Materializer;
import akka.stream.javadsl.Flow;
import play.mvc.*;
import javax.inject.Inject;
import java.util.*;
import play.libs.ws.*;
import play.libs.F;
import play.libs.streams.ActorFlow;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import views.html.twitter.*;
import play.data.DynamicForm;
import play.data.FormFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;


public class TwitterController extends Controller implements WSBodyReadables, WSBodyWritables{

    ActorSystem system;
    Materializer materializer;
    ActorRef userParentActor;

    private final String access_token = "AAAAAAAAAAAAAAAAAAAAAHB%2F4wAAAAAAI69NlJD0CNk9SlQRy697nPF5oJQ%3DVYBnbQFjiGCL2WIXFuH3QJmOrGNmEO6kCjcXwZkdL7Z3sZHPhM";
    private final WSClient ws;

    @Inject FormFactory formFactory;
    @Inject
    public TwitterController(final WSClient ws, ActorSystem system, Materializer materializer) {
        this.ws = ws;
        this.system = system;
        this.materializer = materializer;
        userParentActor=system.actorOf(Props.create(UserParentActor.class,system,materializer),"userParentActor");
    }

    public Result welcome() {
        return ok(welcome.render(request()));
    }

    public Result livesearch(String keyword){
        userParentActor.tell(new Messages.RequestForNewTweets(keyword),ActorRef.noSender());
        return ok();
    }

    public WebSocket ws() {
        return  WebSocket.Json.acceptOrResult(requestHeader->{
            if(sameOriginCheck(requestHeader))
            {
                System.out.println("Got here");
                F.Either<Result, Flow<JsonNode, JsonNode, ?>> either= F.Either.Right(ActorFlow.actorRef(webSocketActor->TweetActor.props(webSocketActor),system,materializer)) ;
                return CompletableFuture.completedFuture(either);
            }else{
                return  forbiddenResult();
            }
        });
    }

    private boolean sameOriginCheck(Http.RequestHeader rh) {
        final Optional<String> origin = rh.header("Origin");

        if (! origin.isPresent()) {
            System.out.println("originCheck: rejecting request because no Origin header found");
            return false;
        } else if (originMatches(origin.get())) {
            System.out.println("originCheck: originValue = " + origin);
            return true;
        } else {
            System.out.println("originCheck: rejecting request because Origin header value " + origin + " is not in the same origin");
            return false;
        }
    }

    private boolean originMatches(String origin) {
        return origin.contains("localhost:9000") || origin.contains("localhost:19001");
    }

    private CompletionStage<F.Either<Result, Flow<JsonNode, JsonNode, ?>>> forbiddenResult() {
        final Result forbidden = Results.forbidden("forbidden");
        final F.Either<Result, Flow<JsonNode, JsonNode, ?>> left = F.Either.Left(forbidden);
        return CompletableFuture.completedFuture(left);
    }

    public JsonNode tweetSearch(String keyword){
        List<String> keywords = new ArrayList<String>(Arrays.asList(keyword.split(" ")));
        ObjectMapper mapper = new ObjectMapper();
        ArrayNode tweets = mapper.createArrayNode();

        for (int i = 0; i < keywords.size(); i++) {
            if(i>0){
                keywords.set(i, keywords.get(i-1) + " " + keywords.get(i));
            }
            String q = keywords.get(i);
            WSRequest search = ws.url("https://api.twitter.com/1.1/search/tweets.json")
                    .addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
                    .addHeader("Authorization", "Bearer "+access_token)
                    .addQueryParameter("q", q)
                    .addQueryParameter("count", "10");
            CompletionStage<JsonNode> jsonPromise = search.get().thenApply(r -> r.getBody(json()));
            JsonNode jsonData = jsonPromise.toCompletableFuture().join();

            for(JsonNode node : jsonData.path("statuses")) {
                String text = node.path("text").asText();
                String username = node.path("user").path("name").asText();
                String userscreenname = node.path("user").path("screen_name").asText();
                ObjectNode tweet = mapper.createObjectNode();
                tweet.put("username", username);
                tweet.put("screenname", userscreenname);
                tweet.put("text", text);
                tweets.add(tweet);
            }
        }
        return tweets;
    }

    public Result searchSubmit(){
        DynamicForm dynamicForm = formFactory.form().bindFromRequest();
        String keyword = dynamicForm.get("keyword");
        JsonNode jsonData = tweetSearch(keyword);
        return ok(search.render(jsonData));
    }

    public JsonNode userSearch(String screenName){
        WSRequest usersearch = ws.url("https://api.twitter.com/1.1/users/show.json")
                .addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
                .addHeader("Authorization", "Bearer "+access_token)
                .addQueryParameter("screen_name", screenName);
        CompletionStage<JsonNode> userjsonPromise = usersearch.get().thenApply(r -> r.getBody(json()));
        JsonNode userData = userjsonPromise.toCompletableFuture().join();

        WSRequest tweetsearch = ws.url("https://api.twitter.com/1.1/statuses/user_timeline.json")
                .addHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
                .addHeader("Authorization", "Bearer "+access_token)
                .addQueryParameter("screen_name", screenName)
                .addQueryParameter("count", "10");
        CompletionStage<JsonNode> tweetjsonPromise = tweetsearch.get().thenApply(r -> r.getBody(json()));
        JsonNode usertweetData = tweetjsonPromise.toCompletableFuture().join();

        ObjectMapper mapper = new ObjectMapper();

        long id = userData.path("id").asLong();
        String name = userData.path("name").asText();
        String screen_name = userData.path("screen_name").asText();
        String location = userData.path("location").asText();
        String description = userData.path("description").asText();

        ArrayNode tweets = mapper.createArrayNode();

        for(JsonNode node : usertweetData) {
            String text = node.path("text").asText();
            ObjectNode tweet = mapper.createObjectNode();
            tweet.put("text", text);
            tweets.add(tweet);
        }

        ObjectNode user = mapper.createObjectNode();
        user.put("userid", id);
        user.put("name", name);
        user.put("screen_name", screen_name);
        user.put("location", location);
        user.put("description", description);
        user.put("tweets", tweets);

        return user;
    }

    public Result userSubmit(String screenName){
        JsonNode jsonData = userSearch(screenName);
        return ok(user.render(jsonData));
    }

}