$(function() {

    $("#getTweets").click(function () {
        if ($("#searchInput").val().length == 0) {
            alert("Please enter the search keyword");
            return;
        }
        else {
            $.get("/livesearch/"+$("#searchInput").val(),function (event) {
                console.log(event);
            });
            $("#liveHead").css("display", "block");
        }
    });
    const ws = new WebSocket($("body").data("ws-url"));
    ws.onopen=function (ev) {
        console.log("Websocket opened");
    }
    ws.onmessage=function (ev) {
        var jsOb = JSON.parse(event.data);
        var screenName = jsOb.ScreenName;
        var name = jsOb.Name;
        var tweet = jsOb.Tweet;
        var htmlCode='<li class="tweet" style="background: #FFF; padding: 20px 60px 20px 60px;"><ul><li><p style="font-size: 28px;" id="userName">'+name+'</p></li><li><p style="color: #007bff; font-size: 22px; font-style: italic;" id="screenName"><a href="/user/'+screenName+'">@'+screenName+'</a></p></li><li><p style="font-size: 22px; font-style: bold;" id="tweet">'+tweet+'</p></li></ul></li>';
        $("#liveTweets").prepend(htmlCode);
    }
    ws.onclose=function (ev) {
        console.log("Websockets closed");
    }
    ws.onerror=function(ev){
        console.log(ev);
        console.log("Error occured");
    }
});