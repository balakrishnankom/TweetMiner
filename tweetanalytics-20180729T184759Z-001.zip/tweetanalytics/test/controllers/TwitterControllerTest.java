package controllers;

import org.junit.Test;
import play.mvc.Http;
import play.mvc.Result;
import play.test.WithApplication;
import static org.junit.Assert.*;
import static play.test.Helpers.GET;
import static play.test.Helpers.route;

public class TwitterControllerTest extends WithApplication{

    @Test
    public void welcome() {
        //status Ok:200
        Http.RequestBuilder getRequest = new Http.RequestBuilder()
                .method(GET)
                .uri("/");

        Result resultExpected = route(app, getRequest);
        assertEquals(200, resultExpected.status());

    }

    @Test
    public void tweetSearch() {
        //status OK:200
        Http.RequestBuilder getRequest= new Http.RequestBuilder()
                .method(GET)
                .uri("/search?keyword=canada+goose");
        Result resultExpected =route(app, getRequest);
        assertEquals(200, resultExpected.status());
    }

    @Test
    public void userSearch() {
        //status OK:200
        Http.RequestBuilder getRequest= new Http.RequestBuilder()
                .method(GET)
                .uri("/user/SusanDuncanolp");
        Result resultExpected =route(app, getRequest);
        assertEquals(200, resultExpected.status());
    }
}
